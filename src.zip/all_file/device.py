#device check file
import platform
def bit():
	return platform.architecture()[0]
class device:
	bit = bit