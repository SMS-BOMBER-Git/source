#contract
import os,requests,json
import subprocess
from all_file import banner
from all_file import char as x
from all_file import colors
from all_file import social
from all_file import randomColor as r
from all_file import email
from all_file import device as oparetingSystem
version = "2.1.8"

def run():
	banner.home.bannerPrint(version)
	options = f'''{r.randomColor.color}
    [1] Facebook
    [2] Chat
    [3] Instagram
    [4] Twiter
    [5] GitHub
    [6] YouTube
    [7] Telegram
    [8] Sent Email
		'''
	x.printf.char(options,  0.01)
	inputOp = str(input(colors.color.greenBold+"    Please Choose a Option: "))
	inputOp = inputOp.replace(" ","")
	inputOp = inputOp.replace("0","")
	if inputOp == "1":
		social.fb()
	elif inputOp == "2":
		social.chat()
	elif inputOp == "3":
		social.insta()
	elif inputOp == "4":
		social.twiter()
	elif inputOp == "5":
		social.github()
	elif inputOp == "6":
		social.yt()
	elif inputOp == "7":
		social.telegram()
	elif inputOp == "8":
		email.run()
	else:
		x.printf.char("    "+colors.color.redBold+"Invalid",0.01)
