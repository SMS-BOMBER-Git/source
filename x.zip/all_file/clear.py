#clear
from all_file import osGet
import os
def screen():
	if osGet.oparetingSystem.name == 'linux':
		os.system("clear")
	elif osGet.oparetingSystem.name == 'windows':
		os.system('cls')
	else:
		os.system("clear")