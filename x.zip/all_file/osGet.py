#os check
#its helps make a tool os indifendent
import os
def osGet():
	if (os.name == "nt"):
		return "windows"
	else:
		return "linux"
class oparetingSystem:
	name = osGet()