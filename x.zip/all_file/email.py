import requests,json,subprocess
from all_file import colors
from all_file import banner
from all_file import char as x
from all_file import colors
version = "2.1.8"
def run():
	
	banner.home.bannerPrint(version)
	while True:
		name = str(input(colors.color.greenBold+"    Please Enter Your Name: "+ colors.color.end))
		if not len(name):
			x.printf.char(colors.color.redBold+"    Name Feild Empty.",0.01)
		else:
			break
	while True:
		email = str(input(colors.color.greenBold+"    Please Enter Your Email: "+ colors.color.end))
		if "@gmail.com" not in email:
			x.printf.char(colors.color.redBold+"    Enter Valid Email",0.01)
		else:
			break
		
	while True:
		phone = str(input(colors.color.greenBold+"    Please Enter Your Phone Number: "+ colors.color.end))
		if len(phone) != 11:
			x.printf.char(colors.color.redBold+"    Enter 11 Digit Number.",0.01)
		else:
			break
	while True:
		message = str(input(colors.color.greenBold+"    Please Enter Your Message: "+ colors.color.end))
		if not len(message):
			x.printf.char(colors.color.redBold+"    Message Feild Empty.",0.01)
		else:
			break
	cpu_id = str(subprocess.check_output("getprop ro.boot.cpuid",shell=True).decode()).replace("\n","")
	device_brand = subprocess.check_output("getprop ro.product.brand",shell=True).decode().replace("\n","")
	device_model = subprocess.check_output("getprop ro.product.model",shell=True).decode().replace("\n","")
	msg=f'''
	
		{message}
		
		
		
		Cpu ID: {cpu_id}
		Device Model: {device_model}
		Device Brand: {device_brand}
	'''
	url = "https://smtp-lovat.vercel.app/sentEmail"
	data = json.dumps({
	"Name":name,
	"Phone":phone,
	"Email":email,
	"Message":msg})
	headers = {
  'Content-Type': 'application/json'
}
	try:
		req = requests.request("POST", url, headers=headers, data=data)
		if len(req.text) == 688:
			x.printf.char(colors.color.greenBold+"    Email Successfully Sent..",0.01)
		else:
			x.printf.char(colors.color.redBold+"    Email Not Sent..",0.01)
	except Exception as err:
		print(err)