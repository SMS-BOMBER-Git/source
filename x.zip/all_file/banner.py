#banner 
import random,os
from all_file import osGet,clear
path = os.getcwd()
colorArr = ["\033[1;91m", "\033[1;92m", "\033[1;93m",
            "\033[1;94m", "\033[1;95m", "\033[1;96m"]
def banner(version):
    a = random.choice(colorArr)
    r = random.choice(colorArr)
    u = random.choice(colorArr)
    logo = f'''

{a}	 █████╗   {r}  ██████╗  {u}   ██╗   ██╗
{a}	██╔══██╗  {r}  ██╔══██╗ {u}   ██║   ██║
{a}	███████║  {r}  ██████╔╝ {u}   ██║   ██║
{a}	██╔══██║  {r}  ██╔══██╗ {u}   ██║   ██║
{a}	██║  ██║  {r}  ██║  ██║ {u}   ╚██████╔╝
{a}	╚═╝  ╚═╝  {r}  ╚═╝  ╚═╝ {u}    ╚═════╝ 
	'''
    infoC = random.choice(colorArr)
    toolsInfo = f'''{infoC}
    ╔════════════════════════════════════╗
    ║             {random.choice(colorArr)}SMS BOMBER {infoC}            ║
    ║     {random.choice(colorArr)}AUTHOR: ARIFUL ISLAM ARMAN {infoC}    ║
    ║           {random.choice(colorArr)}VERSION : {version}  {infoC}        ║
    ║          {random.choice(colorArr)} STATUS : FREE    {infoC}        ║
    ╚════════════════════════════════════╝
    '''
    
    clear.screen()
    if osGet.oparetingSystem.name == 'linux':
    	move = path+"/all_file"
    	os.chdir(move)
    	os.system('lolcat banner.ts')
    elif osGet.oparetingSystem.name == 'windows':
    	print(logo)
    else:
    	os.system('lolcat banner.ts')
    print(toolsInfo)
    
    
    
    
def bannerSentPin(version):
    a = random.choice(colorArr)
    r = random.choice(colorArr)
    u = random.choice(colorArr)
    logo = f'''

{a}	 █████╗   {r}  ██████╗  {u}   ██╗   ██╗
{a}	██╔══██╗  {r}  ██╔══██╗ {u}   ██║   ██║
{a}	███████║  {r}  ██████╔╝ {u}   ██║   ██║
{a}	██╔══██║  {r}  ██╔══██╗ {u}   ██║   ██║
{a}	██║  ██║  {r}  ██║  ██║ {u}   ╚██████╔╝
{a}	╚═╝  ╚═╝  {r}  ╚═╝  ╚═╝ {u}    ╚═════╝ 
	'''
    infoC = random.choice(colorArr)
    toolsInfo = f'''{infoC}
    ╔════════════════════════════════════╗
    ║             {random.choice(colorArr)}SMS BOMBER {infoC}            ║
    ║     {random.choice(colorArr)}AUTHOR: ARIFUL ISLAM ARMAN {infoC}    ║
    ║           {random.choice(colorArr)}VERSION : {version}  {infoC}        ║
    ╚════════════════════════════════════╝
    '''
    clear.screen()
    if osGet.oparetingSystem.name == 'linux':
    	move = path+"/all_file"
    	os.chdir(move)
    	os.system('lolcat banner.ts')
    elif osGet.oparetingSystem.name == 'windows':
    	print(logo)
    else:
    	os.system('lolcat banner.ts')
    print(toolsInfo)
    
    
class home:
	bannerPrint = banner


class main:
	bannerPrint = bannerSentPin