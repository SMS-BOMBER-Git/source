#Download and extract
import requests,os
import base64
import zipfile, urllib.request, shutil
def run():
	base64_string ="aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL0FydS1Jcy1BbHdheXMtS2luZy9ib21iaW5nX2RhdGEvbWFpbi9ib21iZXIuanNvbg=="
	base64_bytes = base64_string.encode("ascii")
	sample_string_bytes = base64.b64decode(base64_bytes)
	sample_string = sample_string_bytes.decode("ascii")
  
	try:
		toolsInfo = requests.get(sample_string).json()
		url = toolsInfo["fileDownloadUrl"]
		file_name = 'myzip.zip'	
		with urllib.request.urlopen(url) as response, open(file_name, 'wb') as out_file:
		    shutil.copyfileobj(response, out_file)
		    with zipfile.ZipFile(file_name) as zf:
		        zf.extractall()
		        os.system("rm -rf myzip.zip")
	except Exception as e:
		print(e)
	