#char print
import sys,time
def printchar(w, t):
	for word in w + '\n':
		sys.stdout.write(word)
		sys.stdout.flush()
		time.sleep(t)
class printf:
	char = printchar