#color
# Color Value
blueVal = "94m"
redVal = "91m"
greenVal = "32m"
whiteVal = "97m"
yellowVal = "93m"
cyanVal = "96m"
# normal
normal = "\33["
# Bold
bold = "\033[1;"
# italic
italic = "\x1B[3m"
# Color Normal
class color:
	blue = normal + blueVal  # Blue Color Normal
	red = normal + redVal  # Red Color Normal
	green = normal + greenVal  # Green Color Normal
	white = normal + whiteVal  # white Color Normal
	yellow = normal + yellowVal  # yellow Color Normal
	cyan = normal + cyanVal  # Cyan Color Normal
	# Color Bold
	blueBold = bold + blueVal  # Blue Color Bold
	redBold = bold + redVal  # Red Color Bold
	greenBold = bold + greenVal  # Green Color Bold
	whiteBold = bold + whiteVal  # white Color Bold
	yellowBold = bold + yellowVal  # yellow Color Bold
	cyanBold = bold + cyanVal  # Cyan Color Bold
	# color end
	end = '\033[0m'