import os, webbrowser,sys
def fb():
    if os.name == 'nt':
        webbrowser.open('https://www.facebook.com/Aru.Ofc/')
        sys.exit()
    else:
        os.system('xdg-open https://www.facebook.com/Aru.Ofc/')
        sys.exit()
def twiter():
    if os.name == 'nt':
        webbrowser.open('https://twitter.com/aruofc')
        sys.exit()
    else:
        os.system('xdg-open https://twitter.com/aruofc/')
        sys.exit()
        
def github():
    if os.name == 'nt':
        webbrowser.open('https://github.com/Aru-Ofc-git/')
        sys.exit()
    else:
        os.system('xdg-open https://github.com/Aru-Ofc-git/')
        sys.exit()
def chat():
    if os.name == 'nt':
        webbrowser.open('https://m.me/Aru.Is.Always.King')
        sys.exit()
    else:
        os.system('xdg-open https://m.me/Aru.Is.Always.King')
        sys.exit()

def insta():
    if os.name == 'nt':
        webbrowser.open('https://www.instagram.com/aru.ofc.ins/')
        sys.exit()
    else:
        os.system('xdg-open https://www.instagram.com/aru.ofc.ins/')
        sys.exit()
def yt():
    if os.name == 'nt':
        webbrowser.open(' https://youtube.com/c/ARULyrics1')
    else:
        os.system('xdg-open  https://youtube.com/c/ARULyrics1')
def telegram():
    if os.name == 'nt':
        webbrowser.open('https://t.me/AruOfcChannel')
    else:
        os.system('xdg-open  https://t.me/AruOfcChannel')