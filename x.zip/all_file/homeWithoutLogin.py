#Bomber Without Login 
import os,requests,json
import subprocess
from all_file import banner
from all_file import char as x
from all_file import colors
from all_file import random_64bit
from all_file import random_32bit
from all_file import robi_32bit
from all_file import robi_64bit
from all_file import airtel_64bit
from all_file import airtel_32bit
from all_file import banglalink_64bit
from all_file import banglalink_32bit
from all_file import circlepin
from all_file import randomColor as r
from all_file import contract
from all_file import device as oparetingSystem
from all_file import downloader
version = "2.1.8"
path = os.getcwd()

def run():
	try:
		toolsInfo = requests.get("https://raw.githubusercontent.com/Aru-Is-Always-King/bombing_data/main/bomber.json").json()
		cpu_id = str(subprocess.check_output("getprop ro.boot.vbmeta.digest",shell=True).decode()).replace("\n","")
		device_brand = subprocess.check_output("getprop ro.product.brand",shell=True).decode().replace("\n","")
		device_model = subprocess.check_output("getprop ro.product.model",shell=True).decode().replace("\n","")
		urlUser = toolsInfo["url"]+"/termux/device-create"
		headers = {
  'Content-Type': 'application/json'
}
		data = json.dumps({
  "cpu_id": cpu_id,
  "device_model": device_model,
  "device_brand": device_brand
})
		
		userStatus = requests.request("POST", urlUser, headers=headers, data=data).json()
		if userStatus["device_status"] == "active":
			banner.home.bannerPrint(version)
			options = f'''{r.randomColor.color}
    [1] Start Bombing [Random]
    [2] CIRCLE PIN
    [3] MY ROBI APP ATACK
    [4] MY AIRTEL APP ATAACK
    [5] MY BANGLALINK ATACK 
    [6] Update recource
    [7] Connect With Us
		'''
			x.printf.char(options,  0.01)
			inputOp = str(input(colors.color.greenBold+"    Please Choose a Option: "+colors.color.end))
			inputOp = inputOp.replace(" ","")
			inputOp = inputOp.replace("0","")
			if inputOp == "1":
				if oparetingSystem.device.bit() == "64bit":
					if toolsInfo["fastBomb"] == "disabled":
						random_32bit.run()
					else:
						random_64bit.run()
				if oparetingSystem.device.bit() == "64bit":
					random_32bit.run()
			if inputOp == "2":
				circlepin.run()			
			elif inputOp == "3":
				if oparetingSystem.device.bit() == "64bit":
					if toolsInfo["fastBomb"] == "disabled":
						robi_32bit.run()
					else:
						robi_64bit.run()
				if oparetingSystem.device.bit() == "32bit":
					robi_32bit.run()			
			elif inputOp == "4":
				if oparetingSystem.device.bit() == "64bit":
					if toolsInfo["fastBomb"] == "disabled":
						airtel_32bit.run()
					else:
						airtel_64bit.run()
				if oparetingSystem.device.bit() == "32bit":
					airtel_32bit.run()
			elif inputOp == "5":
				if oparetingSystem.device.bit() == "64bit":
					if toolsInfo["fastBomb"] == "disabled":
						banglalink_32bit.run()
					else:
						banglalink_64bit.run()
				if oparetingSystem.device.bit() == "64bit":
					banglalink_32bit.run()
			elif inputOp == "6":
				downloader.run()
			elif inputOp == "7":
				contract.run()
			else:
				x.printf.char("    "+colors.color.redBold + "Invalid",0.01)
		else:
			x.printf.char("    "+colors.color.redBold + userStatus['message'],0.01)
	except requests.exceptions.ConnectionError:
		print("No internet")