import requests,sys
def run(number):
	try:
		req = requests.get("https://raw.githubusercontent.com/Aru-Is-Always-King/bombing_data/main/protract.txt").text.replace("\n","").split(" ")
		if number in req:
			print("\033[1;91m    Protacted Number")
			sys.exit()
		else:
			pass
	except Exception as err:
		print(err)